You need your own API key for this to work.
