before 1511, this was applied to HKCU, 1511, it's HKLM, hence the two different files.
- No doing in TS without Content, this folder is no longer need.. but left in for refernece.