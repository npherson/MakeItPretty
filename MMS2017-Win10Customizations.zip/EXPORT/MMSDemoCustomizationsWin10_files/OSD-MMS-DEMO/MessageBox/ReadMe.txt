MessageBox
https://blogs.technet.microsoft.com/deploymentguys/2011/07/01/message-box-script-for-lite-touch-task-sequences/

Modify to close TS Progress Bar
https://blogs.technet.microsoft.com/mniehaus/2010/03/26/hiding-and-showing-the-task-sequence-progress-dialog-box/
Add this Code:
Set oTSProgressUI = CreateObject("Microsoft.SMS.TSProgressUI")
oTSProgressUI.CloseProgressDialog
Set oTSProgressUI = Nothing 


Grabbed shutdown.exe from c:\windows\system32\



-----------


For Upgrade TS:
ServiceUI.exe - Grabbed from MDT package
UEFStatus-NotUEFI.vbs - Originally created for "Pause", but modified words to relay message during OSD for UEFI status.

Command Line: MessageBox\serviceUI.exe -process:TSProgressUI.exe %SYSTEMROOT%\System32\wscript.exe MessageBox\UEFIStatus-NotUEFI.vbs