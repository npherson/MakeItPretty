No longer using this Folder, registry keys are in the TS now.
Info borrowed from here:
http://www.tenforums.com/tutorials/6015-pc-folders-add-remove-windows-10-a.html

