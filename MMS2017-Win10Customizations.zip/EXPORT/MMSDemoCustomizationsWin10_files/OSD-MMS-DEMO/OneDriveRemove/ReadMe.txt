Removes SkyDrive ShellFolder in Explorer
http://www.howtogeek.com/167058/how-to-disable-skydrive-integration-in-windows-8.1/

Updated to use this method for Windows 10:
:: Tutorial: http://www.tenforums.com/tutorials/4818-onedrive-add-remove-navigation-pane-windows-10-a.html

--

Deletes the key from the Default User Profile to start the Setup process when user logs on first time.
"DeleteOneDriveSetup-...Cmd"


