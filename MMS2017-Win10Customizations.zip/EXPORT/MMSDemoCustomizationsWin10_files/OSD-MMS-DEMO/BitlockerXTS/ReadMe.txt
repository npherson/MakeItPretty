https://garytown.com/enable-bitlocker-xts-256-during-osd-w-mbam-2-5-sp1

MBAM Settings: (You will need to export this from one of your current MBAM clients, to get the correct Registry data, but here is mine as example � your service endpoint strings will be completely different than the example, as well as other potential differences depending on your Security policy)

[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\FVE\MDOPBitLockerManagement]