This is ONLY For Lab, I'm creating Fake Apps and images so the Start Menu works.
5/12/18 - Items removed, as they were being triggered by AV scanners.
Because these are all missing now, the Start Menu's in this demo will probably not look correct.  
However you'd use want to use your won anyway.
https://docs.microsoft.com/en-us/windows/configuration/customize-and-export-start-layout