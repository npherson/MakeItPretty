Wallpapers
This is done in the TS itself
xcopy WallPapersLockScreens\DM_Corp.jpg C:\Windows\Web\Wallpaper\Windows\img0.jpg /Q /Y