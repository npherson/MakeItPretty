Update 2018 - OneDrive doesn't like to uninstall during TS at all on new builds. :-(

Update 2017 - No longer using these script.
All Functions have been moved to TS, and set to run on the Default User.


Removes SkyDrive ShellFolder in Explorer
http://www.howtogeek.com/167058/how-to-disable-skydrive-integration-in-windows-8.1/

Updated to use this method for Windows 10:
:: Tutorial: http://www.tenforums.com/tutorials/4818-onedrive-add-remove-navigation-pane-windows-10-a.html

--

Deletes the key from the Default User Profile to start the Setup process when user logs on first time.
"DeleteOneDriveSetup-...Cmd"


