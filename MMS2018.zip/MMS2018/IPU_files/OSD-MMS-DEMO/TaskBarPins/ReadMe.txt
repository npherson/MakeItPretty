--
Don't Do this ANYMORE!
Jorgen has Supported info in his Blog... go there... he also explains this method as well.  ccmexec.com

--

In the registry:
HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband

In a folder:
%AppData%\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar


PinTo10 = I was unable to get the IE icon to pin to Taskbar, found this way to do it.
Found info here: https://connect.microsoft.com/PowerShell/feedback/details/1609288/pin-to-taskbar-no-longer-working-in-windows-10
Using the "RunOnce" registry Value of the Default User to make it run this command on user's first logon
