cmd /c "SETRES.exe" -r 1280x1024

http://www.windows-noob.com/forums/index.php?/topic/666-screen-resolution-during-osd-with-sccm-mdt-integrated/

Using to Set res on my VM test machines